---
layout: faq
question: "How can I tell if I'm addicted to social media? 📲❤️"
order: 5
---

Social media addiction signs include compulsively checking apps throughout the day, feeling anxious when unable to access social platforms, experiencing FOMO when seeing others' posts, spending more time online than intended, neglecting real-world relationships and responsibilities, using social media to cope with negative emotions, and continuing to use platforms despite knowing they make you feel worse. Physical signs may include poor posture from device use, eye strain, and sleep disruption from late-night scrolling. 📱😵‍💫